const loginbutton = document.querySelector(".loginbutton");
loginbutton.addEventListener("click", () => {
    window.open("profile.html", "_self");
})