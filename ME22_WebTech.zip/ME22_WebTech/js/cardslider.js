const slider = document.querySelector(".slider");
const leftArrowBtn = document.getElementById("left-arrow");
const rightArrowBtn = document.getElementById("right-arrow");
const profileCard = document.querySelector(".profile-card");

let pointerPosition;

let sliderScrollLeft;

let isDrag = false;

let cardWidth = profileCard.offsetWidth;

const start = (event) => {
  isDrag = true;
  pointerPosition = event.pageX;
  sliderScrollLeft = slider.scrollLeft;
  slider.classList.add("drag");
};

const drag = (event) => {
  if (!isDrag) return;
  slider.scrollLeft = sliderScrollLeft - (event.pageX - pointerPosition);
};

const stop = () => {
  isDrag = false;

  slider.classList.remove("drag");
};

leftArrowBtn.addEventListener("click", () => {
  slider.scrollLeft += -(cardWidth + 19);
});

rightArrowBtn.addEventListener("click", () => {
  slider.scrollLeft += cardWidth + 19;
});

slider.addEventListener("mousedown", start);
slider.addEventListener("mousemove", drag);
slider.addEventListener("mouseup", stop);