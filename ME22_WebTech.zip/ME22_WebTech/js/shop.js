$(document).ready(async function () {
    const getJson = (path) => {
        return new Promise((resolve) => {
            $.getJSON("../database/shop.json", function (data) {
                setTimeout(() => {
                    resolve(data);
                }, 1);
            });
        })
    }
    var result = await getJson('test.json');
    console.log(result);

    const maincontainer = document.querySelector(".cardcontainer");

    let tmp = "";

    for (let i = 0; i < result.trees.length; i += 4) {
        tmp = `<div class="row">
    <div class="card-deck">
        <div class="card">
            <img class="card-img-top" src="${result.trees[i].image}" alt="">
            <div class="card-body">
                <h5 class="card-title">${result.trees[i].name}</h5>
                <p class="card-text">${result.trees[i].description}</p>
            </div>
            <div class="card-footer">
                <small class="text-muted">${result.trees[i].price}</small>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="${result.trees[i + 1].image}" alt="">
            <div class="card-body">
                <h5 class="card-title">${result.trees[i + 1].name}</h5>
                <p class="card-text">${result.trees[i + 1].description}</p>
            </div>
            <div class="card-footer">
                <small class="text-muted">${result.trees[i + 1].price}</small>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="${result.trees[i + 2].image}" alt="">
            <div class="card-body">
                <h5 class="card-title">${result.trees[i + 2].name}</h5>
                <p class="card-text">${result.trees[i + 2].description}</p>
            </div>
            <div class="card-footer">
                <small class="text-muted">${result.trees[i + 2].price}</small>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="${result.trees[i + 3].image}" alt="">
            <div class="card-body">
                <h5 class="card-title">${result.trees[i + 3].name}</h5>
                <p class="card-text">${result.trees[i + 3].description}</p>
            </div>
            <div class="card-footer">
                <small class="text-muted">${result.trees[i + 3].price}</small>
            </div>
        </div>
    </div>
</div>`;
        maincontainer.innerHTML += tmp;
    }

    for (let i = 0; i < result.flowers.length; i += 4) {
        tmp = `<div class="row">
    <div class="card-deck">
        <div class="card">
            <img class="card-img-top" src="${result.flowers[i].image}" alt="">
            <div class="card-body">
                <h5 class="card-title">${result.flowers[i].name}</h5>
                <p class="card-text">${result.flowers[i].description}</p>
            </div>
            <div class="card-footer">
                <small class="text-muted">${result.flowers[i].price}</small>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="${result.flowers[i + 1].image}" alt="">
            <div class="card-body">
                <h5 class="card-title">${result.flowers[i + 1].name}</h5>
                <p class="card-text">${result.flowers[i + 1].description}</p>
            </div>
            <div class="card-footer">
                <small class="text-muted">${result.flowers[i + 1].price}</small>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="${result.flowers[i + 2].image}" alt="">
            <div class="card-body">
                <h5 class="card-title">${result.flowers[i + 2].name}</h5>
                <p class="card-text">${result.flowers[i + 2].description}</p>
            </div>
            <div class="card-footer">
                <small class="text-muted">${result.flowers[i + 2].price}</small>
            </div>
        </div>
        <div class="card">
            <img class="card-img-top" src="${result.flowers[i + 3].image}" alt="">
            <div class="card-body">
                <h5 class="card-title">${result.flowers[i + 3].name}</h5>
                <p class="card-text">${result.flowers[i + 3].description}</p>
            </div>
            <div class="card-footer">
                <small class="text-muted">${result.flowers[i + 3].price}</small>
            </div>
        </div>
    </div>
</div>`;
        maincontainer.innerHTML += tmp;
    }
});