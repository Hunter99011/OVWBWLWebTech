$(document).ready(function() {
    $('.card').hover(
      function() {
        $(this).css({
          'transform': 'scale(1.05)',
          'transition': 'transform 0.3s'
        });
      },
      function() {
        $(this).css({
          'transform': 'scale(1)',
          'transition': 'transform 0.3s'
        });
      }
    );
  });