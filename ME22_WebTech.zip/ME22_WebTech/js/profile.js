jQuery(document).ready(function($) {
	tab = $('.tabs h3 a');

	tab.on('click', function(event) {
		event.preventDefault();
		tab.removeClass('active');
		$(this).addClass('active');

		tab_content = $(this).attr('href');
		$('div[id$="tab-content"]').removeClass('active');
		$(tab_content).addClass('active');
	});
});

function validateLogin() {
    const userlogin = document.querySelector("#user_login");
    const userpass = document.querySelector("#user_pass2");
    if (userlogin.value.length <= 6) {
        userlogin.style.border = "1px solid red";
    } else {
        userlogin.style.border = "1px solid #CFCFCF";
    }

    if (userpass.value.length <= 6) {
        userpass.style.border = "1px solid red";
    } else {
        userpass.style.border = "1px solid #CFCFCF";
    }
 }
  
const submitbutton = document.querySelector(".submitbutton");
submitbutton.addEventListener("click", (e) => {
    e.preventDefault();
    validateLogin();
});

function validateRegister() {
    const useremail = document.querySelector("#user_email");
    const username = document.querySelector("#user_name");
    const userpass = document.querySelector("#user_pass");
    if (useremail.value.length <= 12) {
        useremail.style.border = "1px solid red";
    } else {
        useremail.style.border = "1px solid #CFCFCF";
    }

    if (username.value.length <= 6) {
        username.style.border = "1px solid red";
    } else {
        username.style.border = "1px solid #CFCFCF";
    }

    if (userpass.value.length <= 8) {
        userpass.style.border = "1px solid red";
    } else {
        userpass.style.border = "1px solid #CFCFCF";
    }
 }

const submitbuttonreg = document.querySelector(".submitbuttonreg");
submitbuttonreg.addEventListener("click", (e) => {
    e.preventDefault();
    validateRegister();
});